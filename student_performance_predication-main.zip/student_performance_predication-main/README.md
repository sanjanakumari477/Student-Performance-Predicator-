🎯 Student Performance Prediction
This Django web application allows users to upload student data (CSV format) and perform data analysis to predict student performance.

✨ Key Features
Upload student data via CSV file

Display uploaded data in tabular form

Analyze performance trends using visual charts (bar, pie, line)

Predict student performance based on attributes

Clean and responsive UI with HTML/CSS

Django Admin Panel for data management

Error handling for invalid uploads

Insights by study time, parental education, and more
