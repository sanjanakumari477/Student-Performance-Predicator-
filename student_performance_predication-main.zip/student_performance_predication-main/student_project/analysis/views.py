import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib
matplotlib.use('Agg')  # Use a non-GUI backend
import matplotlib.pyplot as plt

from django.shortcuts import render
from .forms import UploadFileForm
import os
from django.conf import settings

# Ensure MEDIA_ROOT exists
os.makedirs(settings.MEDIA_ROOT, exist_ok=True)

# Global variable
df = None


def handle_uploaded_file(f):
    try:
        path = os.path.join(settings.MEDIA_ROOT, 'uploaded.csv')
        with open(path, 'wb+') as destination:
            for chunk in f.chunks():
                destination.write(chunk)
        return path
    except Exception as e:
        print(f"Error saving file: {e}")
        return None


def index(request):
    global df  # ✅ Make df truly global

    context = {}
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            file_path = handle_uploaded_file(request.FILES['file'])
            if file_path and os.path.exists(file_path):
                try:
                    df = pd.read_csv(file_path)
                    context['file_uploaded'] = True  # Show "View" button
                except Exception as e:
                    context['error'] = f'Error reading CSV: {e}'
            else:
                context['error'] = 'File not uploaded or not found.'
    else:
        form = UploadFileForm()

    context['form'] = form
    return render(request, 'analysis/index.html', context)


def view_data(request):
    global df  

    context = {}

    if df is None:
        context['error'] = 'No data available. Please upload a CSV file first.'
        return render(request, 'analysis/analysis_tab.html', context)

    try:
        if 'passed' in df.columns:
            df['passed'] = df['passed'].map({'yes': 1, 'no': 0})
        
        summary = df.describe(include='all').to_html()

        
        numeric_df = df.apply(pd.to_numeric, errors='coerce').dropna(axis=1, how='all')

        
        if 'passed' in numeric_df.columns:
            plt.figure(figsize=(8, 12))
            correlation = numeric_df.corr()[['passed']].sort_values(by='passed', ascending=False)
            sns.heatmap(correlation, vmin=-1, vmax=1, annot=True, cmap='BrBG')
            passed_heatmap_path = os.path.join(settings.MEDIA_ROOT, 'passed_heatmap.png')
            plt.savefig(passed_heatmap_path)
            plt.close()
            context['passed_heatmap_url'] = '/media/passed_heatmap.png'


        # Bar chart - Going Out vs Passed 
        if 'passed' in df.columns and 'goout' in df.columns:
                    
                    try:
                    # Compute percentage distribution
                        perc = (lambda col: col / col.sum())
                        index = [0, 1]  # 0: Failed, 1: Passed
                        out_tab = pd.crosstab(index=df['passed'], columns=df['goout'])
                        out_perc = out_tab.apply(perc).reindex(index)

                        # Plot bar chart
                        plt.figure(figsize=(14, 6))
                        out_perc.plot.bar(colormap="mako_r", fontsize=16)
                        plt.title('Student Status By Frequency of Going Out', fontsize=20)
                        plt.ylabel('Percentage of Students', fontsize=16)
                        plt.xlabel('Student Status (0 = Fail, 1 = Pass)', fontsize=16)

                        # Save the plot to media folder
                        goout_bar_path = os.path.join(settings.MEDIA_ROOT, 'goout_bar.png')
                        plt.savefig(goout_bar_path)
                        plt.close()

                        # Pass image URL to template
                        context['goout_bar_url'] = '/media/goout_bar.png'

                    except Exception as e:
                        context['error'] = f"Error creating 'Go Out' bar chart: {str(e)}"
                    

                    try:
                        # romantic status
                        romance_tab1=pd.crosstab(index=df['passed'],columns=['romantic'])
                        romance_tab=np.log(romance_tab1)
                        romance_perc = romance_tab.apply(perc).reindex(index)
                        plt.figure()
                        romance_perc.plot.bar(colormap="PiYG_r",fontsize=16,figsize=(8,8))
                        plt.title('Student status By Romantic relation',fontsize=20)
                        plt.ylabel('Percentage of Logarithm Student Counts',fontsize=16)
                        plt.xlabel('Student status',fontsize=16)
                        
                        romance_bar_path=os.path.join(settings.MEDIA_ROOT,'romance_bar.png')
                        plt.savefig(romance_bar_path)
                        plt.close()


                        context['romance_bar_url']='/media/romance_bar.png'


                    except Exception as e:
                        context['error']=f"Error creating 'Go Out' bar chart:{str(e)}"
                    

                    try:
                        f, ax = plt.subplots(figsize=(10, 6))
                        custom_colors = ['#FF9999', '#66B2FF', '#99FF99', '#FFCC99', '#C2C2F0']
                        sns.countplot(x='Mjob', data=df, order=['teacher', 'health', 'services', 'at_home', 'other'], ax=ax,palette=custom_colors)
                        ax.set(ylabel="Count", xlabel="Mother job")
                        ax.grid(False)

                        mjob_plot_path = os.path.join(settings.MEDIA_ROOT, 'mjob_bar.png')
                        plt.savefig(mjob_plot_path)


                        context['mjob_bar_url'] = '/media/mjob_bar.png'


                    except Exception as e:
                        context['error']=f"Error creating 'Go Out' bar chart:{str(e)}"
                    
                    try:
                        mjob_tab1 = pd.crosstab(index=df['passed'],columns=df['Mjob'])
                        mjob_tab = np.log(mjob_tab1)
                        mjob_perc = mjob_tab.apply(perc).reindex(index)
                        plt.figure()
                        mjob_perc.plot.bar(colormap="mako_r",fontsize=16,figsize=(8,8))
                        plt.title('Student status By mother JOB',fontsize=20)
                        plt.ylabel('Percentage of Logarithm Student Counts',fontsize=16)
                        plt.xlabel('Student status',fontsize=16)


                        mjob1_plot_path=os.path.join(settings.MEDIA_ROOT,'mjob1_bar.png')
                        plt.savefig(mjob1_plot_path)


                        context['mjob1_bar_url']='/media/mjob1_bar.png'


                        
                    except Exception as e:
                        context['error']=f"Error creating 'Go Out' bar chart:{str(e)}"

        
        
        # Full numeric correlation heatmap
        if not numeric_df.empty:
            plt.figure(figsize=(10, 12))
            sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm")
            heatmap_path = os.path.join(settings.MEDIA_ROOT, 'heatmap.png')
            plt.savefig(heatmap_path)
            plt.close()
            context['heatmap_url'] = '/media/heatmap.png'

        # Data and summary
        context.update({
            'data': df.head().to_html(),
            'summary': summary,
        })

    except Exception as e:
        context['error'] = f'Error processing data: {e}'

    return render(request, 'analysis/analysis_tab.html', context)