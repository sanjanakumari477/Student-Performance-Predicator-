from django.urls import path
from .views import index, view_data

urlpatterns = [
    path('', index, name='upload_csv'),
    path('view/', view_data, name='view_data'),
]
